export interface Product {
  id: string;
  name: string;
  description: string;
  ingredients: string[];
  skinType: string[];
  category: string;
  priceUSD: number;
  pricePKR: number;
  image: string;
  badge?: 'New' | 'Best Seller';
}

export interface Bundle {
  id: string;
  name: string;
  products: string[];
  priceUSD: number;
  pricePKR: number;
  savings: number;
  image: string;
}

//todo: remove mock functionality - Replace with real product data
export const products: Product[] = [
  {
    id: '1',
    name: 'Hydrating Hyaluronic Acid Serum',
    description: 'Deep moisture boost with multi-weight hyaluronic acid for plump, dewy skin. Absorbs instantly without sticky residue.',
    ingredients: ['Hyaluronic Acid', 'Niacinamide', 'Panthenol'],
    skinType: ['Dry', 'Normal', 'Combination'],
    category: 'Serums',
    priceUSD: 28,
    pricePKR: 7800,
    image: 'serum',
    badge: 'Best Seller'
  },
  {
    id: '2',
    name: 'Snail Mucin Power Essence',
    description: 'Repair and hydrate with 96% snail secretion filtrate. Fades scars, smooths texture, and strengthens skin barrier naturally.',
    ingredients: ['Snail Mucin', 'Betaine', 'Allantoin'],
    skinType: ['All Types'],
    category: 'Essences',
    priceUSD: 24,
    pricePKR: 6700,
    image: 'essence',
    badge: 'Best Seller'
  },
  {
    id: '3',
    name: 'Centella Calming Cream',
    description: 'Soothe irritation and redness with pure centella asiatica extract. Lightweight gel-cream texture perfect for sensitive skin routines.',
    ingredients: ['Centella Asiatica', 'Madecassoside', 'Ceramides'],
    skinType: ['Sensitive', 'Combination', 'Acne-Prone'],
    category: 'Moisturizers',
    priceUSD: 32,
    pricePKR: 8900,
    image: 'cream'
  },
  {
    id: '4',
    name: 'Vitamin C Brightening Serum',
    description: 'Fade dark spots and boost radiance with stabilized vitamin C and ferulic acid. Evens tone, protects from environmental damage daily.',
    ingredients: ['Vitamin C', 'Ferulic Acid', 'Vitamin E'],
    skinType: ['Dull', 'Normal', 'Dry'],
    category: 'Serums',
    priceUSD: 35,
    pricePKR: 9750,
    image: 'serum',
    badge: 'New'
  },
  {
    id: '5',
    name: 'Green Tea Clay Mask',
    description: 'Purify pores and control oil with organic green tea and kaolin clay. Gentle exfoliation reveals fresh, balanced, clarified complexion.',
    ingredients: ['Green Tea Extract', 'Kaolin Clay', 'Salicylic Acid'],
    skinType: ['Oily', 'Combination', 'Acne-Prone'],
    category: 'Masks',
    priceUSD: 22,
    pricePKR: 6100,
    image: 'mask'
  },
  {
    id: '6',
    name: 'Rice Enzyme Powder Cleanser',
    description: 'Gentle daily exfoliation with rice enzyme powder. Brightens and smooths texture while maintaining natural moisture balance beautifully.',
    ingredients: ['Rice Extract', 'Papain Enzyme', 'Coconut Oil'],
    skinType: ['All Types'],
    category: 'Cleansers',
    priceUSD: 26,
    pricePKR: 7250,
    image: 'essence'
  },
  {
    id: '7',
    name: 'Niacinamide Pore Refining Serum',
    description: 'Minimize pores and control sebum with 10% niacinamide and zinc. Refines texture, reduces breakouts, promotes clear glowing skin.',
    ingredients: ['Niacinamide', 'Zinc PCA', 'Witch Hazel'],
    skinType: ['Oily', 'Acne-Prone', 'Combination'],
    category: 'Serums',
    priceUSD: 29,
    pricePKR: 8100,
    image: 'serum',
    badge: 'Best Seller'
  },
  {
    id: '8',
    name: 'Propolis Energy Ampoule',
    description: 'Restore vitality with 83% propolis extract. Anti-inflammatory formula soothes, heals, and provides intense nourishment for tired skin.',
    ingredients: ['Propolis Extract', 'Royal Jelly', 'Honey'],
    skinType: ['Dry', 'Sensitive', 'Mature'],
    category: 'Serums',
    priceUSD: 38,
    pricePKR: 10600,
    image: 'serum'
  },
  {
    id: '9',
    name: 'Cica Tea Tree Sheet Mask',
    description: 'Calm breakouts and soothe inflammation with cica and tea tree. Cooling hydrogel sheet delivers targeted treatment for problem areas.',
    ingredients: ['Centella Asiatica', 'Tea Tree Oil', 'Aloe Vera'],
    skinType: ['Acne-Prone', 'Sensitive', 'Oily'],
    category: 'Masks',
    priceUSD: 18,
    pricePKR: 5000,
    image: 'mask',
    badge: 'New'
  },
  {
    id: '10',
    name: 'Mineral Sun Essence SPF 50+',
    description: 'Lightweight mineral sunscreen with no white cast. Zinc oxide and titanium dioxide protect while nourishing with botanical extracts daily.',
    ingredients: ['Zinc Oxide', 'Titanium Dioxide', 'Centella'],
    skinType: ['All Types'],
    category: 'Sunscreen',
    priceUSD: 27,
    pricePKR: 7500,
    image: 'sunscreen',
    badge: 'Best Seller'
  },
  {
    id: '11',
    name: 'Retinol Repair Night Cream',
    description: 'Combat aging with encapsulated retinol and peptides. Reduces fine lines, firms skin, and renews overnight without irritation worries.',
    ingredients: ['Retinol', 'Peptides', 'Ceramides'],
    skinType: ['Mature', 'Dry', 'Normal'],
    category: 'Moisturizers',
    priceUSD: 42,
    pricePKR: 11700,
    image: 'cream'
  },
  {
    id: '12',
    name: 'Black Sugar Lip Scrub',
    description: 'Buff away dry lips with natural black sugar crystals and shea butter. Leaves lips soft, smooth, perfectly prepped for balm.',
    ingredients: ['Black Sugar', 'Shea Butter', 'Vitamin E'],
    skinType: ['All Types'],
    category: 'Lip Care',
    priceUSD: 15,
    pricePKR: 4200,
    image: 'mask'
  },
  {
    id: '13',
    name: 'Galactomyces Toner Essence',
    description: 'Brighten and refine with 95% galactomyces ferment. First-step hydrating essence preps skin, boosts radiance, improves overall skin health.',
    ingredients: ['Galactomyces', 'Niacinamide', 'Adenosine'],
    skinType: ['All Types'],
    category: 'Toners',
    priceUSD: 30,
    pricePKR: 8350,
    image: 'essence',
    badge: 'Best Seller'
  },
  {
    id: '14',
    name: 'Sleeping Beauty Overnight Mask',
    description: 'Wake to dewy, refreshed skin with this deeply hydrating overnight mask. Lavender and ceramides repair and lock in moisture beautifully.',
    ingredients: ['Ceramides', 'Lavender Oil', 'Hyaluronic Acid'],
    skinType: ['Dry', 'Normal', 'Combination'],
    category: 'Masks',
    priceUSD: 34,
    pricePKR: 9450,
    image: 'cream'
  },
  {
    id: '15',
    name: 'Azelaic Acid Spot Treatment',
    description: 'Target stubborn dark spots and acne with 10% azelaic acid. Fades hyperpigmentation, evens tone, prevents future breakouts effectively gently.',
    ingredients: ['Azelaic Acid', 'Niacinamide', 'Salicylic Acid'],
    skinType: ['Acne-Prone', 'Oily', 'Combination'],
    category: 'Treatments',
    priceUSD: 25,
    pricePKR: 6950,
    image: 'serum',
    badge: 'New'
  },
  {
    id: '16',
    name: 'Probiotic Barrier Cream',
    description: 'Strengthen skin barrier with probiotics and prebiotics. Balances microbiome, soothes irritation, protects against environmental stressors daily effectively.',
    ingredients: ['Probiotics', 'Prebiotics', 'Ceramides'],
    skinType: ['Sensitive', 'Dry', 'Normal'],
    category: 'Moisturizers',
    priceUSD: 36,
    pricePKR: 10000,
    image: 'cream'
  },
  {
    id: '17',
    name: 'Peptide Eye Recovery Serum',
    description: 'Revive tired eyes with peptide complex and caffeine. Reduces puffiness, dark circles, fine lines around delicate eye area beautifully.',
    ingredients: ['Peptides', 'Caffeine', 'Hyaluronic Acid'],
    skinType: ['All Types'],
    category: 'Eye Care',
    priceUSD: 33,
    pricePKR: 9200,
    image: 'serum'
  },
  {
    id: '18',
    name: 'Mugwort Calming Toner',
    description: 'Soothe and balance with pure mugwort extract. Anti-inflammatory toner calms redness, preps skin, and delivers gentle hydration daily.',
    ingredients: ['Mugwort Extract', 'Panthenol', 'Beta-Glucan'],
    skinType: ['Sensitive', 'Combination', 'Acne-Prone'],
    category: 'Toners',
    priceUSD: 28,
    pricePKR: 7800,
    image: 'essence'
  },
  {
    id: '19',
    name: 'Pearl Brightening Sleeping Mask',
    description: 'Wake to luminous skin with pearl extract and arbutin. Overnight brightening mask fades dullness, evens tone while you sleep.',
    ingredients: ['Pearl Extract', 'Arbutin', 'Niacinamide'],
    skinType: ['Dull', 'Normal', 'Dry'],
    category: 'Masks',
    priceUSD: 31,
    pricePKR: 8600,
    image: 'cream',
    badge: 'New'
  },
  {
    id: '20',
    name: 'Collagen Firming Essence',
    description: 'Boost elasticity with marine collagen and adenosine. Plumps fine lines, firms skin, restores youthful bounce and resilience naturally.',
    ingredients: ['Marine Collagen', 'Adenosine', 'Peptides'],
    skinType: ['Mature', 'Dry', 'Normal'],
    category: 'Essences',
    priceUSD: 40,
    pricePKR: 11150,
    image: 'essence'
  }
];

//todo: remove mock functionality - Replace with real bundle data
export const bundles: Bundle[] = [
  {
    id: 'b1',
    name: 'Hydration Hero Bundle',
    products: ['1', '2', '14'],
    priceUSD: 75,
    pricePKR: 20900,
    savings: 19,
    image: 'serum'
  },
  {
    id: 'b2',
    name: 'Acne Clear Kit',
    products: ['7', '5', '9'],
    priceUSD: 60,
    pricePKR: 16700,
    savings: 9,
    image: 'mask'
  },
  {
    id: 'b3',
    name: 'Glow Starter Set',
    products: ['4', '13', '10'],
    priceUSD: 80,
    pricePKR: 22300,
    savings: 12,
    image: 'essence'
  },
  {
    id: 'b4',
    name: 'Anti-Aging Luxury',
    products: ['11', '17', '20'],
    priceUSD: 105,
    pricePKR: 29250,
    savings: 10,
    image: 'cream'
  },
  {
    id: 'b5',
    name: 'Sensitive Skin Savior',
    products: ['3', '18', '16'],
    priceUSD: 85,
    pricePKR: 23700,
    savings: 11,
    image: 'cream'
  }
];
