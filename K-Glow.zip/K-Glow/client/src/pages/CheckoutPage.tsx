import { useState } from 'react';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import serumImg from '@assets/generated_images/Serum_product_image_2e9e2bab.png';
import creamImg from '@assets/generated_images/Cream_product_image_d22274a5.png';
import maskImg from '@assets/generated_images/Sheet_mask_product_1dd8daf6.png';
import essenceImg from '@assets/generated_images/Essence_toner_product_4c0483bb.png';
import sunscreenImg from '@assets/generated_images/Sunscreen_product_image_ed5dda25.png';

const imageMap: Record<string, string> = {
  serum: serumImg,
  cream: creamImg,
  mask: maskImg,
  essence: essenceImg,
  sunscreen: sunscreenImg
};

export default function CheckoutPage() {
  const { cart, cartTotal, currency, clearCart } = useCart();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    postalCode: '',
    country: '',
    phone: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    const requiredFields = ['email', 'firstName', 'lastName', 'address', 'city', 'postalCode', 'country'];
    const missingFields = requiredFields.filter(field => !formData[field as keyof typeof formData]);
    
    if (missingFields.length > 0) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    // Simulate order placement
    toast({
      title: "Order Placed!",
      description: "Your order has been successfully placed. Check your email for confirmation.",
    });
    
    clearCart();
    setLocation('/');
  };

  const totalFormatted = currency === 'USD' 
    ? `$${cartTotal.toFixed(2)}` 
    : `PKR ${cartTotal.toLocaleString()}`;

  const shippingCost = cartTotal >= 50 ? 0 : (currency === 'USD' ? 5 : 500);
  const shippingFormatted = shippingCost === 0 
    ? 'FREE' 
    : (currency === 'USD' ? `$${shippingCost}` : `PKR ${shippingCost}`);

  const finalTotal = cartTotal + shippingCost;
  const finalTotalFormatted = currency === 'USD' 
    ? `$${finalTotal.toFixed(2)}` 
    : `PKR ${finalTotal.toLocaleString()}`;

  if (cart.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Your cart is empty</h2>
          <Button onClick={() => setLocation('/')} data-testid="button-back-to-shop">
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <h1 className="text-3xl md:text-4xl font-semibold mb-8" data-testid="text-checkout-title">Checkout</h1>

        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <form onSubmit={handleSubmit} className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      data-testid="input-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone (optional)</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      data-testid="input-phone"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Shipping Address</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                        required
                        data-testid="input-first-name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                        required
                        data-testid="input-last-name"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      required
                      data-testid="input-address"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        required
                        data-testid="input-city"
                      />
                    </div>
                    <div>
                      <Label htmlFor="postalCode">Postal Code</Label>
                      <Input
                        id="postalCode"
                        value={formData.postalCode}
                        onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                        required
                        data-testid="input-postal-code"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Input
                      id="country"
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      required
                      data-testid="input-country"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Payment</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Payment processing will be integrated with Stripe or JazzCash in production.
                  </p>
                  <div className="bg-secondary/50 p-4 rounded-lg text-sm">
                    <p className="font-medium mb-2">Integration Ready:</p>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Stripe API placeholder</li>
                      <li>• JazzCash integration point</li>
                      <li>• Secure payment processing</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Button type="submit" size="lg" className="w-full" data-testid="button-place-order">
                Place Order
              </Button>
            </form>
          </div>

          <div>
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {cart.map(item => (
                    <div key={item.id} className="flex gap-3" data-testid={`order-item-${item.id}`}>
                      <div className="w-16 h-16 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                        <img
                          src={imageMap[item.image] || serumImg}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{item.name}</p>
                        <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                        <p className="text-sm font-semibold">
                          {currency === 'USD' ? `$${item.priceUSD}` : `PKR ${item.pricePKR}`}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span data-testid="text-order-subtotal">{totalFormatted}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Shipping</span>
                    <span data-testid="text-order-shipping">{shippingFormatted}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg pt-2 border-t">
                    <span>Total</span>
                    <span data-testid="text-order-total">{finalTotalFormatted}</span>
                  </div>
                </div>

                {cartTotal >= 50 && (
                  <div className="bg-accent/20 p-3 rounded-lg text-sm text-center">
                    🎉 You've qualified for free shipping!
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
