import { useState } from 'react';
import Hero from '@/components/Hero';
import ProductGrid from '@/components/ProductGrid';
import ProductModal from '@/components/ProductModal';
import BundlesSection from '@/components/BundlesSection';
import LaunchOffer from '@/components/LaunchOffer';
import Testimonials from '@/components/Testimonials';
import Newsletter from '@/components/Newsletter';
import Footer from '@/components/Footer';
import { products, bundles, Product } from '@shared/products';

export default function HomePage() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery] = useState('');

  const filteredProducts = searchQuery
    ? products.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : products;

  return (
    <div>
      <Hero />
      <LaunchOffer />
      <ProductGrid 
        products={filteredProducts} 
        onViewDetails={setSelectedProduct}
      />
      <BundlesSection bundles={bundles} />
      <Testimonials />
      <Newsletter />
      <Footer />
      <ProductModal
        product={selectedProduct}
        open={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
}
