import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Star } from 'lucide-react';

//todo: remove mock functionality - Replace with real testimonials
const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    initials: 'SJ',
    text: 'The Hydrating Serum transformed my dry skin in just two weeks. My skin feels plump and dewy all day long!',
    rating: 5
  },
  {
    id: 2,
    name: 'Emily Chen',
    initials: 'EC',
    text: 'Finally found products that work for my sensitive skin. The Centella Cream is a game changer. No irritation whatsoever.',
    rating: 5
  },
  {
    id: 3,
    name: 'Maya Patel',
    initials: 'MP',
    text: 'Love the Vitamin C Serum! My dark spots have faded significantly and my skin looks so much brighter.',
    rating: 5
  }
];

export default function Testimonials() {
  return (
    <section className="py-12 md:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold mb-4" data-testid="text-testimonials-title">
            Loved by Thousands
          </h2>
          <p className="text-muted-foreground">
            See what our customers are saying about their skin transformations
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map(testimonial => (
            <Card key={testimonial.id} className="hover-elevate" data-testid={`card-testimonial-${testimonial.id}`}>
              <CardContent className="p-6">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-primary text-primary" data-testid={`star-${testimonial.id}-${i}`} />
                  ))}
                </div>
                <p className="text-sm leading-relaxed mb-4" data-testid={`text-testimonial-${testimonial.id}`}>
                  "{testimonial.text}"
                </p>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback className="bg-primary/10 text-primary">{testimonial.initials}</AvatarFallback>
                  </Avatar>
                  <span className="font-medium text-sm" data-testid={`text-name-${testimonial.id}`}>{testimonial.name}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
