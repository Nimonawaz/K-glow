import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export default function LaunchOffer() {
  return (
    <section className="py-12 md:py-16">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <Card className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 border-primary/20 overflow-hidden">
          <div className="p-8 md:p-12 text-center">
            <div className="inline-block bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-medium mb-4" data-testid="badge-launch-offer">
              Limited Time Offer
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-launch-title">
              Grand Opening: 20% Off Everything
            </h2>
            <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto" data-testid="text-launch-description">
              Celebrate our launch with exclusive savings on all Korean skincare products. Plus free shipping on orders over $50!
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" data-testid="button-shop-launch">Shop Now</Button>
              <Button size="lg" variant="outline" data-testid="button-view-terms">View Terms</Button>
            </div>
            <p className="text-sm text-muted-foreground mt-6" data-testid="text-offer-expiry">
              Offer ends December 31, 2025 • Use code: LAUNCH20
            </p>
          </div>
        </Card>
      </div>
    </section>
  );
}
