import { Bundle, products } from '@shared/products';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/CartContext';
import serumImg from '@assets/generated_images/Serum_product_image_2e9e2bab.png';
import creamImg from '@assets/generated_images/Cream_product_image_d22274a5.png';
import maskImg from '@assets/generated_images/Sheet_mask_product_1dd8daf6.png';
import essenceImg from '@assets/generated_images/Essence_toner_product_4c0483bb.png';

const imageMap: Record<string, string> = {
  serum: serumImg,
  cream: creamImg,
  mask: maskImg,
  essence: essenceImg,
};

interface BundlesSectionProps {
  bundles: Bundle[];
}

export default function BundlesSection({ bundles }: BundlesSectionProps) {
  const { addToCart, currency } = useCart();

  const handleAddBundle = (bundle: Bundle) => {
    bundle.products.forEach(productId => {
      const product = products.find(p => p.id === productId);
      if (product) addToCart(product);
    });
  };

  return (
    <section className="py-12 md:py-16 lg:py-20 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold mb-4" data-testid="text-bundles-title">
            Curated Bundles
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Save more with our expertly curated skincare sets. Complete routines for every skin concern.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {bundles.map(bundle => {
            const price = currency === 'USD' 
              ? `$${bundle.priceUSD}` 
              : `PKR ${bundle.pricePKR.toLocaleString()}`;

            return (
              <Card key={bundle.id} className="hover-elevate" data-testid={`card-bundle-${bundle.id}`}>
                <CardHeader className="space-y-0 pb-4">
                  <div className="relative aspect-square rounded-md overflow-hidden bg-background mb-4">
                    <img
                      src={imageMap[bundle.image] || serumImg}
                      alt={bundle.name}
                      className="w-full h-full object-cover"
                    />
                    <Badge className="absolute top-2 right-2 bg-accent text-accent-foreground">
                      Save ${bundle.savings}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <h3 className="font-semibold" data-testid={`text-bundle-name-${bundle.id}`}>{bundle.name}</h3>
                  <p className="text-sm text-muted-foreground">{bundle.products.length} products</p>
                  <p className="text-xl font-semibold text-primary" data-testid={`text-bundle-price-${bundle.id}`}>
                    {price}
                  </p>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={() => handleAddBundle(bundle)}
                    data-testid={`button-add-bundle-${bundle.id}`}
                  >
                    Add Bundle
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
