import { useState } from 'react';
import { Product } from '@shared/products';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCart } from '@/contexts/CartContext';
import { Minus, Plus } from 'lucide-react';
import serumImg from '@assets/generated_images/Serum_product_image_2e9e2bab.png';
import creamImg from '@assets/generated_images/Cream_product_image_d22274a5.png';
import maskImg from '@assets/generated_images/Sheet_mask_product_1dd8daf6.png';
import essenceImg from '@assets/generated_images/Essence_toner_product_4c0483bb.png';
import sunscreenImg from '@assets/generated_images/Sunscreen_product_image_ed5dda25.png';

interface ProductModalProps {
  product: Product | null;
  open: boolean;
  onClose: () => void;
}

const imageMap: Record<string, string> = {
  serum: serumImg,
  cream: creamImg,
  mask: maskImg,
  essence: essenceImg,
  sunscreen: sunscreenImg
};

export default function ProductModal({ product, open, onClose }: ProductModalProps) {
  const [quantity, setQuantity] = useState(1);
  const { addToCart, currency } = useCart();

  if (!product) return null;

  const price = currency === 'USD' 
    ? `$${product.priceUSD}` 
    : `PKR ${product.pricePKR.toLocaleString()}`;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    onClose();
    setQuantity(1);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-product-details">
        <DialogHeader>
          <DialogTitle className="text-2xl" data-testid="text-modal-product-name">{product.name}</DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-8 mt-4">
          <div className="relative aspect-square rounded-lg overflow-hidden bg-secondary">
            <img
              src={imageMap[product.image] || serumImg}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.badge && (
              <Badge variant={product.badge === 'New' ? 'default' : 'secondary'} className="absolute top-4 left-4">
                {product.badge}
              </Badge>
            )}
          </div>

          <div className="flex flex-col">
            <div className="flex-1">
              <p className="text-3xl font-semibold text-primary mb-4" data-testid="text-modal-price">{price}</p>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {product.skinType.map(type => (
                  <Badge key={type} variant="outline" data-testid={`badge-modal-skin-type-${type.toLowerCase()}`}>
                    {type}
                  </Badge>
                ))}
              </div>

              <Tabs defaultValue="description" className="mb-6">
                <TabsList className="w-full">
                  <TabsTrigger value="description" className="flex-1" data-testid="tab-description">Description</TabsTrigger>
                  <TabsTrigger value="ingredients" className="flex-1" data-testid="tab-ingredients">Ingredients</TabsTrigger>
                  <TabsTrigger value="howto" className="flex-1" data-testid="tab-howto">How to Use</TabsTrigger>
                </TabsList>
                <TabsContent value="description" className="text-sm leading-relaxed mt-4" data-testid="content-description">
                  {product.description}
                </TabsContent>
                <TabsContent value="ingredients" className="mt-4">
                  <ul className="space-y-2">
                    {product.ingredients.map(ingredient => (
                      <li key={ingredient} className="text-sm flex items-center gap-2" data-testid={`ingredient-${ingredient.toLowerCase().replace(/\s+/g, '-')}`}>
                        <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                        {ingredient}
                      </li>
                    ))}
                  </ul>
                </TabsContent>
                <TabsContent value="howto" className="text-sm leading-relaxed mt-4" data-testid="content-howto">
                  Apply a small amount to clean, dry skin. Gently massage in circular motions until fully absorbed. Use morning and evening for best results.
                </TabsContent>
              </Tabs>
            </div>

            <div className="border-t pt-6 space-y-4">
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium">Quantity:</span>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    data-testid="button-decrease-quantity"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="w-12 text-center font-medium" data-testid="text-quantity">{quantity}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                    data-testid="button-increase-quantity"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <Button className="w-full" size="lg" onClick={handleAddToCart} data-testid="button-modal-add-to-cart">
                Add to Cart
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
