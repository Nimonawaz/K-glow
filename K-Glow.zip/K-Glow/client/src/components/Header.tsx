import { useState } from 'react';
import { ShoppingCart, Search, Menu, X, Sun, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/CartContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  onCartClick: () => void;
  onSearch: (query: string) => void;
}

export default function Header({ onCartClick, onSearch }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { cartCount, currency, setCurrency } = useCart();
  const { theme, toggleTheme } = useTheme();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <div className="flex items-center gap-8">
            <h1 className="font-serif text-2xl font-semibold text-primary">K-Glow</h1>
            <nav className="hidden md:flex gap-6">
              <Button variant="ghost" size="sm" data-testid="button-shop">Shop</Button>
              <Button variant="ghost" size="sm" data-testid="button-bundles">Bundles</Button>
              <Button variant="ghost" size="sm" data-testid="button-about">About</Button>
            </nav>
          </div>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search"
              />
            </div>
          </form>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-1 bg-secondary rounded-lg p-1">
              <Button
                variant={currency === 'USD' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setCurrency('USD')}
                data-testid="button-currency-usd"
                className="h-7 px-3"
              >
                USD
              </Button>
              <Button
                variant={currency === 'PKR' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setCurrency('PKR')}
                data-testid="button-currency-pkr"
                className="h-7 px-3"
              >
                PKR
              </Button>
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              data-testid="button-theme-toggle"
            >
              {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={onCartClick}
              className="relative"
              data-testid="button-cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs" data-testid="badge-cart-count">
                  {cartCount}
                </Badge>
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <form onSubmit={handleSearch} className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-mobile"
                />
              </div>
            </form>
            <nav className="flex flex-col gap-2">
              <Button variant="ghost" className="justify-start" data-testid="button-shop-mobile">Shop</Button>
              <Button variant="ghost" className="justify-start" data-testid="button-bundles-mobile">Bundles</Button>
              <Button variant="ghost" className="justify-start" data-testid="button-about-mobile">About</Button>
            </nav>
            <div className="flex gap-2 mt-4">
              <Button
                variant={currency === 'USD' ? 'default' : 'secondary'}
                size="sm"
                onClick={() => setCurrency('USD')}
                className="flex-1"
                data-testid="button-currency-usd-mobile"
              >
                USD
              </Button>
              <Button
                variant={currency === 'PKR' ? 'default' : 'secondary'}
                size="sm"
                onClick={() => setCurrency('PKR')}
                className="flex-1"
                data-testid="button-currency-pkr-mobile"
              >
                PKR
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
