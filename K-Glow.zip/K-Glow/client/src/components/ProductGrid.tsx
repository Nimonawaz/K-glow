import { useState } from 'react';
import { Product } from '@shared/products';
import ProductCard from './ProductCard';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ProductGridProps {
  products: Product[];
  onViewDetails: (product: Product) => void;
}

export default function ProductGrid({ products, onViewDetails }: ProductGridProps) {
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [skinTypeFilter, setSkinTypeFilter] = useState<string>('all');

  const categories = ['all', ...Array.from(new Set(products.map(p => p.category)))];
  const skinTypes = ['all', 'Dry', 'Oily', 'Combination', 'Sensitive', 'Normal', 'Acne-Prone'];

  const filteredProducts = products.filter(product => {
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    const matchesSkinType = skinTypeFilter === 'all' || product.skinType.includes(skinTypeFilter);
    return matchesCategory && matchesSkinType;
  });

  return (
    <section className="py-12 md:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl md:text-4xl font-semibold mb-2" data-testid="text-products-title">
              Our Products
            </h2>
            <p className="text-muted-foreground">
              Discover our curated collection of Korean skincare essentials
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40" data-testid="select-category">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat} data-testid={`option-category-${cat}`}>
                    {cat === 'all' ? 'All Categories' : cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={skinTypeFilter} onValueChange={setSkinTypeFilter}>
              <SelectTrigger className="w-40" data-testid="select-skin-type">
                <SelectValue placeholder="Skin Type" />
              </SelectTrigger>
              <SelectContent>
                {skinTypes.map(type => (
                  <SelectItem key={type} value={type} data-testid={`option-skin-type-${type}`}>
                    {type === 'all' ? 'All Skin Types' : type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewDetails}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">No products found matching your filters</p>
            <Button 
              variant="outline" 
              onClick={() => {
                setCategoryFilter('all');
                setSkinTypeFilter('all');
              }}
              data-testid="button-clear-filters"
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
