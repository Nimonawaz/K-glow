import { Button } from '@/components/ui/button';
import heroImage from '@assets/generated_images/Korean_skincare_hero_image_9e04a67a.png';

export default function Hero() {
  return (
    <section className="relative h-[500px] md:h-[600px] lg:h-[700px] overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Korean skincare beauty"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent" />
      </div>

      <div className="relative h-full max-w-7xl mx-auto px-4 md:px-6 lg:px-8 flex items-center">
        <div className="max-w-2xl text-white">
          <h2 className="font-serif text-5xl md:text-6xl lg:text-7xl font-light mb-4" data-testid="text-hero-title">
            Glow Naturally
          </h2>
          <p className="text-lg md:text-xl mb-8 text-white/90 leading-relaxed" data-testid="text-hero-subtitle">
            Discover premium Korean skincare powered by nature's finest ingredients.
            Transform your routine with science-backed formulas.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" variant="default" data-testid="button-shop-now" className="backdrop-blur-sm">
              Shop Now
            </Button>
            <Button size="lg" variant="outline" data-testid="button-view-bundles" className="backdrop-blur-sm bg-white/10 border-white/30 text-white hover:bg-white/20">
              View Bundles
            </Button>
          </div>
          <div className="mt-8 flex gap-6 text-sm">
            <span className="text-white/80">Free shipping over $50</span>
            <span className="text-white/80">•</span>
            <span className="text-white/80">30-day returns</span>
          </div>
        </div>
      </div>
    </section>
  );
}
