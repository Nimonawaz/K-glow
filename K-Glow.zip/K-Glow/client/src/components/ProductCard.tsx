import { Product } from '@shared/products';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { useCart } from '@/contexts/CartContext';
import serumImg from '@assets/generated_images/Serum_product_image_2e9e2bab.png';
import creamImg from '@assets/generated_images/Cream_product_image_d22274a5.png';
import maskImg from '@assets/generated_images/Sheet_mask_product_1dd8daf6.png';
import essenceImg from '@assets/generated_images/Essence_toner_product_4c0483bb.png';
import sunscreenImg from '@assets/generated_images/Sunscreen_product_image_ed5dda25.png';

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
}

const imageMap: Record<string, string> = {
  serum: serumImg,
  cream: creamImg,
  mask: maskImg,
  essence: essenceImg,
  sunscreen: sunscreenImg
};

export default function ProductCard({ product, onViewDetails }: ProductCardProps) {
  const { addToCart, currency } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
  };

  const price = currency === 'USD' 
    ? `$${product.priceUSD}` 
    : `PKR ${product.pricePKR.toLocaleString()}`;

  return (
    <Card 
      className="group hover-elevate cursor-pointer overflow-visible" 
      onClick={() => onViewDetails(product)}
      data-testid={`card-product-${product.id}`}
    >
      <CardContent className="p-4">
        <div className="relative aspect-square mb-4 rounded-md overflow-hidden bg-secondary">
          <img
            src={imageMap[product.image] || serumImg}
            alt={product.name}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
          {product.badge && (
            <Badge 
              variant={product.badge === 'New' ? 'default' : 'secondary'} 
              className="absolute top-2 left-2"
              data-testid={`badge-${product.id}-${product.badge.toLowerCase()}`}
            >
              {product.badge}
            </Badge>
          )}
        </div>
        <h3 className="font-medium truncate mb-2" data-testid={`text-product-name-${product.id}`}>
          {product.name}
        </h3>
        <div className="flex flex-wrap gap-1 mb-3">
          {product.skinType.slice(0, 2).map(type => (
            <Badge key={type} variant="outline" className="text-xs" data-testid={`badge-skin-type-${type.toLowerCase()}`}>
              {type}
            </Badge>
          ))}
        </div>
        <p className="text-lg font-semibold text-primary" data-testid={`text-price-${product.id}`}>
          {price}
        </p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full" 
          onClick={handleAddToCart}
          data-testid={`button-add-to-cart-${product.id}`}
        >
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}
