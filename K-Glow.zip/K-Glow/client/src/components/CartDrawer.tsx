import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { Minus, Plus, X } from 'lucide-react';
import serumImg from '@assets/generated_images/Serum_product_image_2e9e2bab.png';
import creamImg from '@assets/generated_images/Cream_product_image_d22274a5.png';
import maskImg from '@assets/generated_images/Sheet_mask_product_1dd8daf6.png';
import essenceImg from '@assets/generated_images/Essence_toner_product_4c0483bb.png';
import sunscreenImg from '@assets/generated_images/Sunscreen_product_image_ed5dda25.png';

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

const imageMap: Record<string, string> = {
  serum: serumImg,
  cream: creamImg,
  mask: maskImg,
  essence: essenceImg,
  sunscreen: sunscreenImg
};

export default function CartDrawer({ open, onClose, onCheckout }: CartDrawerProps) {
  const { cart, removeFromCart, updateQuantity, cartTotal, currency } = useCart();

  const formatPrice = (priceUSD: number, pricePKR: number) => {
    return currency === 'USD' ? `$${priceUSD}` : `PKR ${pricePKR.toLocaleString()}`;
  };

  const totalFormatted = currency === 'USD' 
    ? `$${cartTotal.toFixed(2)}` 
    : `PKR ${cartTotal.toLocaleString()}`;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col" data-testid="drawer-cart">
        <SheetHeader>
          <SheetTitle data-testid="text-cart-title">Shopping Cart ({cart.length})</SheetTitle>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-muted-foreground mb-4" data-testid="text-empty-cart">Your cart is empty</p>
              <Button onClick={onClose} data-testid="button-continue-shopping">Continue Shopping</Button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              {cart.map(item => (
                <div key={item.id} className="flex gap-4 p-4 rounded-lg border" data-testid={`cart-item-${item.id}`}>
                  <div className="w-20 h-20 rounded-md overflow-hidden bg-secondary flex-shrink-0">
                    <img
                      src={imageMap[item.image] || serumImg}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between gap-2 mb-2">
                      <h4 className="font-medium text-sm truncate" data-testid={`text-cart-item-name-${item.id}`}>{item.name}</h4>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 flex-shrink-0"
                        onClick={() => removeFromCart(item.id)}
                        data-testid={`button-remove-${item.id}`}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-sm font-semibold text-primary mb-3" data-testid={`text-cart-item-price-${item.id}`}>
                      {formatPrice(item.priceUSD, item.pricePKR)}
                    </p>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        data-testid={`button-decrease-${item.id}`}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-8 text-center text-sm" data-testid={`text-quantity-${item.id}`}>{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        data-testid={`button-increase-${item.id}`}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t pt-4 space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span data-testid="text-subtotal">{totalFormatted}</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Shipping</span>
                  <span data-testid="text-shipping">Calculated at checkout</span>
                </div>
                <div className="flex justify-between font-semibold text-lg pt-2 border-t">
                  <span>Total</span>
                  <span data-testid="text-total">{totalFormatted}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={onClose} className="flex-1" data-testid="button-continue-shopping-full">
                  Continue Shopping
                </Button>
                <Button onClick={onCheckout} className="flex-1" data-testid="button-checkout">
                  Checkout
                </Button>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
