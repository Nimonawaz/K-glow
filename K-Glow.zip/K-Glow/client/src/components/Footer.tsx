import { Facebook, Instagram, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Footer() {
  return (
    <footer className="bg-secondary/30 border-t">
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-serif text-xl font-semibold text-primary mb-4" data-testid="text-footer-brand">K-Glow</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Premium Korean skincare powered by nature's finest ingredients for radiant, healthy skin.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Shop</h4>
            <ul className="space-y-2 text-sm">
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-all-products">All Products</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-bundles">Bundles</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-new-arrivals">New Arrivals</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-best-sellers">Best Sellers</Button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Customer Care</h4>
            <ul className="space-y-2 text-sm">
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-contact">Contact Us</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-shipping">Shipping Info</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-returns">Returns</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-faq">FAQ</Button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">About</h4>
            <ul className="space-y-2 text-sm">
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-our-story">Our Story</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-ingredients">Ingredients</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-sustainability">Sustainability</Button></li>
              <li><Button variant="ghost" className="h-auto p-0 text-muted-foreground justify-start" data-testid="link-blog">Blog</Button></li>
            </ul>
          </div>
        </div>

        <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © 2025 K-Glow Beauty. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Button variant="ghost" size="icon" data-testid="button-facebook">
              <Facebook className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-instagram">
              <Instagram className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" data-testid="button-twitter">
              <Twitter className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
}
