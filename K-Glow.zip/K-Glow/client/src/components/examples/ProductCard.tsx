import ProductCard from '../ProductCard';
import { products } from '@shared/products';

export default function ProductCardExample() {
  return (
    <div className="p-4 max-w-sm">
      <ProductCard 
        product={products[0]} 
        onViewDetails={(product) => console.log('View details:', product.name)} 
      />
    </div>
  );
}
