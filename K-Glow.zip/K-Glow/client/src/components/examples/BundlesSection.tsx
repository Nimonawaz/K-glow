import BundlesSection from '../BundlesSection';
import { bundles } from '@shared/products';

export default function BundlesSectionExample() {
  return <BundlesSection bundles={bundles} />;
}
