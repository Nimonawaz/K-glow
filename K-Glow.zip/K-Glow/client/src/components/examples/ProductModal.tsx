import { useState } from 'react';
import ProductModal from '../ProductModal';
import { products } from '@shared/products';
import { Button } from '@/components/ui/button';

export default function ProductModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-4">
      <Button onClick={() => setOpen(true)}>Open Product Details</Button>
      <ProductModal 
        product={products[0]} 
        open={open} 
        onClose={() => setOpen(false)} 
      />
    </div>
  );
}
