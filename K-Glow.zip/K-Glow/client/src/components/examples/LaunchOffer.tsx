import LaunchOffer from '../LaunchOffer';

export default function LaunchOfferExample() {
  return <LaunchOffer />;
}
