import ProductGrid from '../ProductGrid';
import { products } from '@shared/products';

export default function ProductGridExample() {
  return (
    <ProductGrid 
      products={products.slice(0, 8)} 
      onViewDetails={(product) => console.log('View details:', product.name)} 
    />
  );
}
