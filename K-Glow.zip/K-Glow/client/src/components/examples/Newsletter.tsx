import Newsletter from '../Newsletter';

export default function NewsletterExample() {
  return <Newsletter />;
}
