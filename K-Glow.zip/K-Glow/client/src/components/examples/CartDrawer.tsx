import { useState } from 'react';
import CartDrawer from '../CartDrawer';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { products } from '@shared/products';

export default function CartDrawerExample() {
  const [open, setOpen] = useState(false);
  const { addToCart } = useCart();

  const handleAddSample = () => {
    addToCart(products[0]);
    addToCart(products[1]);
    setOpen(true);
  };

  return (
    <div className="p-4">
      <Button onClick={handleAddSample}>Add Sample Items & Open Cart</Button>
      <CartDrawer 
        open={open} 
        onClose={() => setOpen(false)} 
        onCheckout={() => console.log('Checkout clicked')} 
      />
    </div>
  );
}
